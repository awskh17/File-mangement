import React from 'react';
import '../App.css'

function Error() {
    return (
        <div className={"pageContent"}>
            <h1>ALARM ERROR!</h1>
        </div>
    );
}

export default Error;