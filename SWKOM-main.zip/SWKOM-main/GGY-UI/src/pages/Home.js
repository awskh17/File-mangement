import React from 'react';
import '../App.css'

function Home() {
    return (
        <div className={"pageContent"}>
            <h1>Welcome!</h1>
            <p>This is GGY, the best document management system you can find!</p>
            <p>By Gwendolin Zitta, Gisela Schaefer, Yusra Sefef</p>
        </div>
    );
}

export default Home;