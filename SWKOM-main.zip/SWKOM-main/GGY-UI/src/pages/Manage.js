import React from 'react';
import '../App.css'

function Manage() {
    return (
        <div className={"pageContent"}>
            <h1>Manage Page</h1>
            <p>Here you can manage your files!</p>
        </div>
    );
}

export default Manage;