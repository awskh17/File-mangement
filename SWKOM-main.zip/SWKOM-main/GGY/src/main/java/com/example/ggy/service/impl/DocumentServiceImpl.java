package com.example.ggy.service.impl;

import com.example.ggy.Search.DocumentSearchService;
import com.example.ggy.data.schema.DocumentEntity;
import com.example.ggy.data.repository.DocumentRepository;
import com.example.ggy.service.DocumentService;
import com.example.ggy.service.minio.MinioService;
import com.example.ggy.service.RabbitMQSender; // Importiere den RabbitMQSender
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service
public class DocumentServiceImpl implements DocumentService {

    @Autowired
    DocumentSearchService docSearch;

    @Autowired
    private DocumentRepository documentRepository;

    @Autowired
    private MinioService minioService;

    @Autowired
    private RabbitMQSender rabbitMQSender;  // Füge RabbitMQSender hinzu
    @Transactional
    @Override
    public DocumentEntity save(MultipartFile file, String name, String documentType, String datetime) {
        try {
            // Zuerst die Datei auf MinIO hochladen und die URL zurückbekommen
            String fileUrl = uploadFileToMinIO(file);

            // Dokument-Objekt erstellen und in der Datenbank speichern
            DocumentEntity document = new DocumentEntity();
            document.setName(name);
            document.setDocumentType(documentType);
            document.setDatetime(datetime);
            document.setPathToDocument(fileUrl);  // Setze die MinIO URL als Pfad
            DocumentEntity savedDocument = documentRepository.save(document);

            System.out.println("name: " + name);
            System.out.println("fileUrl: " + fileUrl);

            // Sende eine Nachricht an RabbitMQ nach erfolgreichem Upload
            //rabbitMQSender.sendMessage(name);

            //JSON Format...
            //rabbitMQSender.sendMessage("{\"file_path\": \"" + fileUrl + "\"}");

            return savedDocument;
        } catch (Exception e) {
            // Logge den Fehler detailliert
            e.printStackTrace();
            throw new RuntimeException("Error uploading file and document", e);
        }
    }

    @Override
    public List<DocumentEntity> findAll() {
        return (List<DocumentEntity>) documentRepository.findAll();
    }

    @Override
    public DocumentEntity findById(Long id) {
        return documentRepository.findById(id).orElse(null);
    }

    @Override
    public List<DocumentEntity> findByElasticSearch(String searchtext) {
        return docSearch.searchByName(searchtext);
    }

    @Override
    public List<DocumentEntity> fuzzySearchDocumentsByName(String name) {
        return documentRepository.findByNameLike(name);
    }

    @Override
    public DocumentEntity update(Long id, DocumentEntity updatedDocument) {
        return documentRepository.findById(id).map(existingDocument -> {
            existingDocument.setName(updatedDocument.getName());
            existingDocument.setDocumentType(updatedDocument.getDocumentType());
            existingDocument.setPathToDocument(updatedDocument.getPathToDocument());
            existingDocument.setDatetime(updatedDocument.getDatetime());
            return documentRepository.save(existingDocument);
        }).orElse(null);
    }

    @Override
    public void delete(Long id) {
        documentRepository.deleteById(id);
    }

    private String uploadFileToMinIO(MultipartFile file) {
        try {
            // Generiere einen eindeutigen Dateinamen
            String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();
            return minioService.uploadDocument(fileName, file);
        } catch (IOException e) {
            throw new RuntimeException("Error reading file content", e);
        }
    }
}
