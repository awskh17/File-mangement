package com.example.ggy.data.repository;

import com.example.ggy.data.schema.DocumentEntity;

import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface DocumentRepository extends CrudRepository<DocumentEntity, Long> {
    // Custom query method to find documents by name containing the search text
    List<DocumentEntity> findByNameContaining(String searchtext);
    //
    List<DocumentEntity> findByNameLike(String name);

}
