package com.example.ggy.Search;

import com.example.ggy.data.schema.DocumentEntity;
import jakarta.persistence.EntityManager;
import org.hibernate.search.mapper.orm.Search;
import org.hibernate.search.mapper.orm.session.SearchSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
    public class DocumentSearchService {

        private final EntityManager entityManager;

        public DocumentSearchService(EntityManager entityManager) {
            this.entityManager = entityManager;
        }

        public List<DocumentEntity> searchByName(String searchText) {
            SearchSession searchSession = Search.session(entityManager);
            return searchSession.search(DocumentEntity.class)
                    .where(f -> f.match().field("name").matching(searchText))
                    .fetchHits(30);  // Fetch the first 30 results
        }
    }