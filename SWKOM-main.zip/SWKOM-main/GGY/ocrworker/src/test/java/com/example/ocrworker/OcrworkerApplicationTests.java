package com.example.ocrworker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OcrworkerApplicationTests {

    @Test
    void contextLoads() {
    }

}
